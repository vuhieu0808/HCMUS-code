#pragma once
std::string removeSpace(std::string s);
bool check(std::string line, int &A, int &B, char &op);
void outputFile(int A, int B, char op, std::ofstream& out);