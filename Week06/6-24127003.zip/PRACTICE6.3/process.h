#pragma once

#define MAX 5050

void input(void);
void solve(void);