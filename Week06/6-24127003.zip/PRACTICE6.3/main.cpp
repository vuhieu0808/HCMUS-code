#include <iostream>
#include <fstream>

#include "process.h"

int main(void) {
    input();
    solve();
    return 0;
}