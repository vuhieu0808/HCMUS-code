#pragma once
std::string removeSpace(std::string& s);