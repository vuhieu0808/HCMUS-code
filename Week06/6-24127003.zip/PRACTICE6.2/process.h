#pragma once
#define MAX 300

void solve(std::string s);