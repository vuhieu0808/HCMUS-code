#pragma once
void solve(std::string s, int& countWord, int& countNumber);