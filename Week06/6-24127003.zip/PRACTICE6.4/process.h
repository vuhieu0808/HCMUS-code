#pragma once

#define MAX 1000010
void input(void);
bool isPrime(int n);
void solve(void);