#pragma once

void inputN(int& N);
void inputAI(int i, int& x);
bool solveA(int N, int a[]);
bool solveB(int N, int a[]);
bool solveC(int N, int a[]);