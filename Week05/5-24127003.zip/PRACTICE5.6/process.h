#pragma once

#define MAX 100
void inputN(int& N, int& M);