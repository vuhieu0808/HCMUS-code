#pragma once

bool isPrime(int n);
void inputN(int& N);
void inputAI(int i, int& x);
void solve(int N, int a[]);