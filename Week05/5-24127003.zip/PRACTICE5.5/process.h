#pragma once
#define MAX 100
void inputN(int& N);
void calcSumDiagonal(int N, int a[MAX][MAX]);
void solveB(int N, int a[MAX][MAX]);
bool magicSquare(int N, int a[MAX][MAX]);