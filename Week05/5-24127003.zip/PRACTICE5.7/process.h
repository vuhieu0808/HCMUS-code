#pragma once

#define MAX 100
void inputN(int& N, int& M);
void solveLeft(int N, int M, int a[MAX][MAX]);
void solveRight(int N, int M, int a[MAX][MAX]);